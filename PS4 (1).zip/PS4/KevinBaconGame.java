import java.io.IOException;
import java.util.*;
import net.datastructures.Graph;
import net.datastructures.Vertex;

/**
 * @Author: Fatma Al Arbawi, CS10, Professor: Tim Pierson
 */

public class KevinBaconGame extends GraphLibrary<String, Set<String>> {
    private Graph<String, Set<String>> graph;  //graph that represents the actor network, vertices are actors, edges are movies
    private String center;                      //current center of "universe"/actor nextwork = Kevin Bacon

    public KevinBaconGame(Graph<String, Set<String>> graph) {
        this.graph = graph;
        this.center = "Kevin Bacon";   //setting initial center to Kevin Bacon
    }

    //This method changes center to new actor
    public void changeCenter(String newCenter) {
        if (((GraphLibrary<String, Set<String>>) graph).hasVertex(newCenter)) {   //check if new center exits, update center
            this.center = newCenter;
        } else {
            System.out.println("Actor not found in the graph");
        }
    }

    //Method findings shortest path from center to a different actor
    public List<String> findShortestPath(String actor) {
        return GraphLibrary.getPath(GraphLibrary.bfs(graph, center), actor); //BFS makes a tree, and finds path in tree
    }

    //Method to count the number of the actors connected to center
    public int countConnectedActors() {
        Set<String> visited = new HashSet<>();  //Set that keeps track of visited
        Queue<String> queue = new LinkedList<>(); //Queue for BFS
        queue.offer(center);                      //BFS started at center
        visited.add(center);                      //Center marked as visited

        while (!queue.isEmpty()) {
            String current = queue.poll(); //get next actor from queue

            for (String neighbor : ((GraphLibrary<String, Set<String>>) graph).outNeighbors(current)) {
                if (!visited.contains(neighbor)) {  //if neighbor hasn't been visited yet
                    visited.add(neighbor);          //Mark as visited
                    queue.offer(neighbor);          //add it to queue
                }
            }
        }
        return visited.size();
    }

    //Method to find the top n actors by their degree
    public List<Map.Entry<String, Integer>> topActorsByDeg(int n) {
        Map<String, Integer> degrees = new HashMap<>(); //Map to store each actor's degree
        for (Vertex<String> vertex : graph.vertices()) {
            String actor = vertex.element();              //For each vertex, get actor's name
            degrees.put(actor, ((GraphLibrary<String, Set<String>>) graph).outDegree(actor));   //For each vertex, store actor's degree
        }
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(degrees.entrySet());
        sortedEntries.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

        if (sortedEntries.size() > n) {
            return sortedEntries.subList(0, n);
        } else {
            return sortedEntries;
        }
    }

    public List<Map.Entry<String, Double>> topActorsByAverageSeparation(int n) {
        Map<String, Double> separations = new HashMap<>();  // Map to store each actor's average separation
        for (Vertex<String> vertex : graph.vertices()) {  // For each vertex in the graph
            String actor = vertex.element();  // Get the actor's name
            Graph<String, Set<String>> bfsTree = GraphLibrary.bfs(graph, actor);  // Create a BFS tree with this actor as center
            double avgSep = GraphLibrary.averageSeperation(bfsTree, actor);  // Calculate average separation
            separations.put(actor, avgSep);  // Store the actor's average separation
        }

        // Sort the map entries by value (average separation) in ascending order, limit to n entries, and return as a list
        List<Map.Entry<String, Double>> sortedEntries = new ArrayList<>(separations.entrySet());
        sortedEntries.sort(Map.Entry.comparingByValue());

        if (sortedEntries.size() > n) {
            return sortedEntries.subList(0, n);
        } else {
            return sortedEntries;
        }
    }

    public static void main(String[] args) throws IOException, IOException {
        Map<String, String> actorIdToName = GraphLibrary.readActors("cs10/PS4files/actors.txt");
        Map<String, String> movieIdToName = GraphLibrary.readMovies("cs10/PS4files/movies.txt");
        Map<String, Set<String>> movieToActors = GraphLibrary.readMovieActors("cs10/PS4files/movie-actors.txt");

        GraphLibrary<String, Set<String>> graph = GraphLibrary.buildGraph(actorIdToName, movieIdToName, movieToActors);

        // Now you can use this graph to create your BaconGame instance
        KevinBaconGame game = new KevinBaconGame(graph);
        // Use the game object to play the Bacon Game

        System.out.println("Working Directory = " + System.getProperty("user.dir"));
    }

}

