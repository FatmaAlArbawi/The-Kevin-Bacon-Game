/**
 * Author: Fatma Al Arbawi, CS10, Professor: Tim Pierson
 */


import net.datastructures.*;
import net.datastructures.Graph;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.Queue;

public class GraphLibrary<V, E> implements Graph<V, E>{
    private final Map<V, Map<V, E>> outgoingEdges;  //map for outgoing edges
    private final Map<V, Map<V, E>> incomingEdges; //map for incoming edges

    public GraphLibrary(){ //constructor
        outgoingEdges = new HashMap<>();
        incomingEdges = new HashMap<>();
    }

    public static <V,E> List<V> randomWalk(Graph<V, E> g, V start, int steps) {
        if (!((GraphLibrary<V, E>) g).hasVertex(start)) { //check if start vertex exists in graph
            return null;
        }

        List<V> path = new ArrayList<>(); //create new array list for paths
        path.add(start);                  //start paths at starting vertex

        V current = start;
        Random rand = new Random();  //variable for random walk

        for (int i = 0; i < steps; i++){   //for each neighbor in 'neighbors' array list
            List<V> neighbors = new ArrayList<>();
            for (V neighbor : ((GraphLibrary<V, E>) g).outNeighbors(current)) { //get all the outgoing neighbors of the current vertex
                neighbors.add(neighbor);
            }

            if (neighbors.isEmpty()){  //if there are no neighbors, end the walk
                break;
            }

            V next = neighbors.get(rand.nextInt(neighbors.size()));  //choose a random neighbor and add it to the path
            path.add(next);
            current = next;  //increment
        }


        return path;
    }

    /**
     * Orders vertices in decreasing order by their in-degree
     * @param g		graph
     * @return		list of vertices sorted by in-degree, decreasing (i.e., largest at index 0)
     */
    public static <V,E> List<V> verticesByInDegree(Graph<V,E> g) {
        List<V> vertices = new ArrayList<>();  //make new array list for vertices
        for (Vertex<V> v: g.vertices()) {  //for each vertex in 'vertices'
            boolean add = vertices.add(v.element());  //get all vertices from the graph
        }

        vertices.sort(new Comparator<V>() {   //sort vertices base don their in-degree
            public int compare(V v1, V v2) {   //compare vertex 1 with vertex 2
                return Integer.compare(((GraphLibrary<V, E>) g).inDegree(v2), ((GraphLibrary<V, E>) g).inDegree(v1));
            }
        });
        return vertices;
    }

    @Override
    public int numVertices() {        //counts number of vertices
        return outgoingEdges.size();
    }

    @Override
    public int numEdges() {         //counts number of edges
        int count = 0;
        for (Map<V, E> edges : outgoingEdges.values()) {
            count += edges.size();
        }
        return count;
    }

    @Override
    public Iterable<Vertex<V>> vertices() {
        return new Iterable<Vertex<V>>() {
            @Override
            public Iterator<Vertex<V>> iterator() {
                return new Iterator<Vertex<V>>() {
                    private Iterator<V> keyIterator = outgoingEdges.keySet().iterator();

                    @Override
                    public boolean hasNext() {
                        return keyIterator.hasNext();
                    }

                    @Override
                    public Vertex<V> next() {
                        V element = keyIterator.next();
                        return new Vertex<V>() {
                            @Override
                            public int size() {
                                return 0;
                            }

                            @Override
                            public boolean isEmpty() {
                                return false;
                            }

                            @Override
                            public Object put(Object o, Object o2) throws InvalidKeyException {
                                return null;
                            }

                            @Override
                            public Object get(Object o) throws InvalidKeyException {
                                return null;
                            }

                            @Override
                            public Object remove(Object o) throws InvalidKeyException {
                                return null;
                            }

                            @Override
                            public Iterable<Object> keys() {
                                return null;
                            }

                            @Override
                            public Iterable<Object> values() {
                                return null;
                            }

                            @Override
                            public Iterable<Entry<Object, Object>> entries() {
                                return null;
                            }

                            @Override
                            public V element() {
                                return element;
                            }
                        };
                    }
                };
            }
        };
    }

    public Iterable<V> getOutNeighbors(V v) {
        Map<V, E> edges = outgoingEdges.get(v);
        return edges == null ? Collections.emptyList(): edges.keySet();
    }

    public boolean hasVertex(V v) {
        for (Vertex<V> vertex : vertices()) {
            if (vertex.equals(v)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Iterable<Edge<E>> edges() {
        return null;   //returns iterable collection of edges
    }

    @Override
    public V replace(Vertex<V> vertex, V v) throws InvalidPositionException {
        return null;   //replaces element of given vertex with a new value
    }

    @Override
    public E replace(Edge<E> edge, E e) throws InvalidPositionException {
        return null;  //replaces value/name for one edge with new name/edge
    }

    @Override
    public Iterable<Edge<E>> incidentEdges(Vertex<V> vertex) throws InvalidPositionException {
        return null;  //returns incident edges for a vertex
    }

    @Override
    public Vertex[] endVertices(Edge<E> edge) throws InvalidPositionException {
        return new Vertex[0];  //returns array of end vertices connected by given edge
    }

    @Override
    public Vertex<V> opposite(Vertex<V> vertex, Edge<E> edge) throws InvalidPositionException {
        return null; //gives opposite vertex connected by given edge
    }

    @Override
    public boolean areAdjacent(Vertex<V> vertex, Vertex<V> vertex1) throws InvalidPositionException {
        return false;   //checks if two vertices are adjacent (connected by an edge)
    }


    public int outDegree(V v) {
        Map<V, E> edges = outgoingEdges.get(v);
        return edges == null ? 0 : edges.size();
    }


    public int inDegree(V v) {
        Map<V, E> edges = incomingEdges.get(v);
        return edges == null ? 0 : edges.size();
    }


    public Iterable<V> outNeighbors(V v) {
        Map<V, E> edges = outgoingEdges.get(v);
        return edges == null ? Collections.emptyList() : edges.keySet();
    }


    public Iterable<V> inNeighbors(V v) {
        Map<V, E> edges = incomingEdges.get(v);
        return edges == null ? Collections.emptyList() : edges.keySet();
    }


    public boolean hasEdge(V u, V v) {
        Map<V, E> edges = outgoingEdges.get(u);
        return edges != null && edges.containsKey(v);
    }


    public E getLabel(V u, V v) {
        Map<V, E> edges = outgoingEdges.get(u);
        return edges == null ? null : edges.get(v);  //returns label on edge from u to v or null if that edge doesn't exist
    }

    @Override
    public Vertex<V> insertVertex(V v) {
        if (!hasVertex(v)){  //if vertex is nonexistent
            outgoingEdges.put(v, new HashMap<>());   //add a new entry for it in the outgoingEdges map
            incomingEdges.put(v, new HashMap<>());   //add a new entry for it in the incomingEdges map
        }
        return new Vertex<V>() {
            @Override
            public int size() {
                return 0;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public Object put(Object o, Object o2) throws InvalidKeyException {
                return null;
            }

            @Override
            public Object get(Object o) throws InvalidKeyException {
                return null;
            }

            @Override
            public Object remove(Object o) throws InvalidKeyException {
                return null;
            }

            @Override
            public Iterable<Object> keys() {
                return null;
            }

            @Override
            public Iterable<Object> values() {
                return null;
            }

            @Override
            public Iterable<Entry<Object, Object>> entries() {
                return null;
            }

            @Override
            public V element() {
                return v;
            }
        };
    }

    @Override
    public Edge<E> insertEdge(Vertex<V> vertex, Vertex<V> vertex1, E e) throws InvalidPositionException {
        return null;
    }

    @Override
    public V removeVertex(Vertex<V> vertex) throws InvalidPositionException {
        return null;
    }

    @Override
    public E removeEdge(Edge<E> edge) throws InvalidPositionException {
        return null;
    }


    public void insertDirected(V u, V v, E e) {
        insertVertex(u);
        insertVertex(v);
        outgoingEdges.get(u).put(v, e);
        incomingEdges.get(v).put(u, e);

    }


    public void insertUndirected(V u, V v, E e) {
        insertDirected(u, v, e);
        insertDirected(v, u, e);

    }


    public void removeVertex(V v) {
        for (V u : inNeighbors(v)){
            outgoingEdges.get(u).remove(v);
        }
        outgoingEdges.remove(v);
        incomingEdges.remove(v);

    }


    public void removeDirected(V u, V v) {
        if (hasVertex(u)) {
            outgoingEdges.get(u).remove(v);
        }
        if (hasVertex(v)){
            incomingEdges.get(v).remove(u);
        }

    }

    public void removeUndirected(V u, V v) {
        removeDirected(u, v);
        removeDirected(v, u);

    }

    public static <V, E> Graph<V, E> bfs(Graph<V, E> g, V source){
        GraphLibrary<V, E> tree = new GraphLibrary<>(); //new graph to store 'shortest path' subtree
        Queue<V> queue = new LinkedList<>(); //Queue to manage vertices to be explored
        Set<V> visited = new HashSet<>();  //HashSet to store visited vertices

        queue.offer(source);  //start with the source vertex for all
        visited.add(source);
        tree.insertVertex(source);

        while (!queue.isEmpty()) {
            V current = queue.poll();  //get vertex to explore/analyze
            for (V neighbor : ((GraphLibrary<V, E>)g).outNeighbors(current)) {  //checking all neighbors of this vertex
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.offer(neighbor);
                    tree.insertVertex(neighbor);
                    tree.insertDirected(current, neighbor, null);
                }
            }
        }
        return tree;
    }

    public static <V, E> List<V> getPath(Graph<V, E> tree, V v) {
        List<V> path = new ArrayList<>(); //list to store paths
        V current = v;

        while (current != null) {
            path.add(current);  //add current vertex to the path
            V parent = null;
            for (Vertex<V> vertex : tree.vertices()) {
                if (((GraphLibrary<V, E>)tree).getLabel(vertex.element(), current) != null) {
                    parent = vertex.element();
                    break;
                }
            }
            current = parent;
        }
        Collections.reverse(path); //reverse the path to get it from the root to vertex

        return path;
    }

    public static <V,E> Set<V> missingVertices(Graph<V, E> graph, Graph<V, E> graph2) {
        Set<V> missing = new HashSet<>(); //Set to store missing vertices

        for (Vertex<V> v: ((GraphLibrary<V, E>)graph).vertices()) {
            if (!((GraphLibrary<V, E>)graph2).hasVertex(v.element())) {
                missing.add((V) v);
            }
        }

        return missing;
    }

    public static <V, E> double averageSeperation(Graph<V, E> tree, V root) {
        int[] totalDist = new int[1]; //Array to store total distance
        int[] totalNodes = new int[1];  //Array to store total # of nodes

        compSeperation(tree, root, 0, totalDist, totalNodes);  //recursive computation from root

        return (double) totalDist[0] / totalNodes[0]; //finding average
    }

    private static <V, E> void compSeperation(Graph<V, E> tree, V node, int depth, int[] totalDist, int[] totalNodes) {
        totalDist[0] += depth; //Add the current depth to the total distance
        totalNodes[0]++;       //increment nodes

        for (V child : ((GraphLibrary<V, E>)tree).outNeighbors(node)) {
            compSeperation(tree, child, depth + 1, totalDist, totalNodes);
        }
    }

    public static Map<String, String> readActors(String filename) throws IOException {
        Map<String, String> actorIdToName = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("\\|");
            actorIdToName.put(parts[0], parts[1]);
        }
        reader.close();
        return actorIdToName;
    }

    public static Map<String, String> readMovies(String filename) throws IOException {
        Map<String, String> movieIdToName = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("\\|");
            movieIdToName.put(parts[0], parts[1]);
        }
        reader.close();
        return movieIdToName;
    }

    public static Map<String, Set<String>> readMovieActors(String filename) throws IOException {
        Map<String, Set<String>> movieToActors = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("\\|");
            String movieId = parts[0];
            String actorId = parts[1];
            movieToActors.computeIfAbsent(movieId, k -> new HashSet<>()).add(actorId);
        }
        reader.close();
        return movieToActors;
    }

    public static GraphLibrary<String, Set<String>> buildGraph(
            Map<String, String> actorIdToName,
            Map<String, String> movieIdToName,
            Map<String, Set<String>> movieToActors) {

        GraphLibrary<String, Set<String>> graph = new GraphLibrary<>();

        for (Map.Entry<String, Set<String>> entry : movieToActors.entrySet()) {
            String movieName = movieIdToName.get(entry.getKey());
            List<String> actors = new ArrayList<>();
            for (String actorId : entry.getValue()) {
                actors.add(actorIdToName.get(actorId));
            }

            for (int i = 0; i < actors.size(); i++) {
                for (int j = i + 1; j < actors.size(); j++) {
                    String actor1 = actors.get(i);
                    String actor2 = actors.get(j);
                    graph.insertVertex(actor1);
                    graph.insertVertex(actor2);

                    Set<String> movies = new HashSet<>();
                    if (graph.hasEdge(actor1, actor2)) {
                        movies = graph.getLabel(actor1, actor2);
                    }
                    movies.add(movieName);
                    graph.insertUndirected(actor1, actor2, movies);
                }
            }
        }

        return graph;
    }

}
